<?php $__env->startSection('content'); ?>
	<div class="panel panel-default">
		<div class="panel-body">
			<?php if(!$user->isAdmin()): ?>
			<div class="row mgb15">
				<div class="col-sm-12">
					<label class="fc-blue">Fill up the required information</label>
				</div>
			</div>
			<form action="<?php echo e(route('adminJobOrderPost',$user->id)); ?>" method="post">
				<?php echo e(csrf_field()); ?>

				<div class="row">
					<div class="col-sm-6">
						<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
							<input type="text" name="name" class="form-control input-sm" value="<?php echo e(old('name')); ?>" placeholder="Name of Requisitioner">
							<?php if($errors->has('name')): ?>
	                            <span class="help-block">
	                                <strong><?php echo e($errors->first('name')); ?></strong>
	                            </span>
	                        <?php endif; ?>
	                    </div>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-6">
						<div class="form-group<?php echo e($errors->has('client_name') ? ' has-error' : ''); ?>">
							<input type="text" name="client_name" class="form-control input-sm" value="<?php echo e(old('client_name')); ?>" placeholder="Client Name">
							<?php if($errors->has('client_name')): ?>
	                            <span class="help-block">
	                                <strong><?php echo e($errors->first('client_name')); ?></strong>
	                            </span>
	                        <?php endif; ?>
	                    </div>
					</div>
					<div class="col-sm-6">
						<div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
							<input type="text" name="address" class="form-control input-sm" value="<?php echo e(old('address')); ?>" placeholder="Address">
							<?php if($errors->has('address')): ?>
	                            <span class="help-block">
	                                <strong><?php echo e($errors->first('address')); ?></strong>
	                            </span>
	                        <?php endif; ?>
	                    </div>
						<div class="form-group<?php echo e($errors->has('contact_number') ? ' has-error' : ''); ?>">
							<input type="text" name="contact_number" class="form-control input-sm" value="<?php echo e(old('contact_number')); ?>" placeholder="Contact Number" maxlength="11">
							<?php if($errors->has('contact_number')): ?>
	                            <span class="help-block">
	                                <strong><?php echo e($errors->first('contact_number')); ?></strong>
	                            </span>
	                        <?php endif; ?>
	                    </div>									
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<div class="form-group<?php echo e($errors->has('particular') ? ' has-error' : ''); ?>">
						<textarea class="form-control input-sm" name="particular" placeholder="Particular"><?php echo e(old('particular')); ?></textarea>
							<?php if($errors->has('particular')): ?>
	                            <span class="help-block">
	                                <strong><?php echo e($errors->first('particular')); ?></strong>
	                            </span>
	                        <?php endif; ?>
	                    </div>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<div class="form-group<?php echo e($errors->has('remarks') ? ' has-error' : ''); ?>">
						<textarea class="form-control input-sm" name="remarks" placeholder="Remarks"><?php echo e(old('remarks')); ?></textarea>
							<?php if($errors->has('remarks')): ?>
	                            <span class="help-block">
	                                <strong><?php echo e($errors->first('remarks')); ?></strong>
	                            </span>
	                        <?php endif; ?>
	                    </div>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12">
						<button type="submit" class="btn btn-primary btn-sm pull-right" id="send"><span class="fa fa-paper-plane"></span> Send Request</button>
					</div>
				</div>
			</form>
			<?php else: ?>
			<div class="row">
				<div class="col-sm-12">
					<label class="fc-blue">Job Order Requests</label>
				</div>						
			</div>
				<?php if(!$job_orders->isEmpty()): ?>
					<div class="table-responsive">
						<table class="table table-striped table-hover">
							<thead>
								<tr>
									<th>Name</th>
									<th>Date</th>
									<th>Status</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach($job_orders as $job_order): ?>
								<tr>
									<td><?php echo e($job_order->name); ?></td>
									<td><?php echo e(date_format($job_order->created_at, 'm-d-Y')); ?></td>
									<td>
										<?php if($job_order->status === null): ?>
										<span class="text-primary">New</span>
										<?php elseif($job_order->status == 1): ?>
										<span class="text-success">Accepted</span>
										<?php elseif($job_order->status == 0): ?>
										<span class="text-danger">Rejected</span>								
										<?php endif; ?>
									</td>
									<td>
										<div class="btn-group btn-group-sm">
											<a href="<?php echo e(route('adminJobOrderPdf',$job_order->id)); ?>" class="btn btn-primary"><span class="fa fa-eye"></span> View</a>
											<?php if($job_order->status === null || $job_order->status == 0): ?>
											<a href="<?php echo e(route('adminJobOrderAccept',[$user->username,$job_order->id])); ?>" class="btn btn-success"><span class="fa fa-check"></span> Accept</a>
											<a href="<?php echo e(route('adminJobOrderReject',[$user->username,$job_order->id])); ?>" class="btn btn-danger"><span class="fa fa-times"></span> Reject</a>
											<?php endif; ?>
										</div>
									</td>
								</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				<?php else: ?>
					<span class="text-muted mgl15">No Job Requests available.</span>
				<?php endif; ?>
			<?php endif; ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script>
		$('#jobOrder').addClass('active');

		$('form').find(':submit').prop('disabled', false);

		$('form').on('submit', function(){
			$(this).find(':submit').prop('disabled', true);
			$('.fa-paper-plane').removeClass('fa-paper-plane').addClass('fa-spinner fa-pulse fa-fw');
		});
	</script>
	<!-- <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	<script>
		$( function() {
			$( "#datepicker" ).datepicker();
		} );
	</script> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>