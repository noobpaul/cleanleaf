<h3>Quick Inquiry Form via Website</h3>

	<div>
		<p> Sent by : <?php echo e($name_inq); ?> </p>
		<p> Contact info : <?php echo e($contact_inq); ?> </p>
		<p> Company Name : <?php echo e($company_inq); ?> </p>
	</div>

	<div>
		<?php echo e($inq); ?>

	</div>
