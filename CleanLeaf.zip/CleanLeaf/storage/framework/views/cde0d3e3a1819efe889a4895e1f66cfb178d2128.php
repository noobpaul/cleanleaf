<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">
        <div class="panel-body">
            <div class="row mgb15">
                <div class="col-md-12">
                    <label class="fc-blue">Register an account</label>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <form method="POST" action="<?php echo e(route('adminRegisterPost',$user->username)); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <input type="text" class="form-control input-sm" name="name" value="<?php echo e(old('name')); ?>" placeholder="Name">
                            <?php if($errors->has('name')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('role') ? ' has-error' : ''); ?>">                            
                            <select class="form-control input-sm" name="role" value="<?php echo e(old('role')); ?>">
                                <option disabled selected>Role</option>
                                <option value="staff">Staff</option>
                                <option value="admin">Administrator</option>
                            </select>
                            <?php if($errors->has('role')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('role')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">                            
                            <input type="email" class="form-control input-sm" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email Address">
                            <?php if($errors->has('email')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary pull-right">
                                <i class="fa fa-btn fa-user"></i> Register
                            </button>
                        </div>
                    </form>                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $('#register').addClass('active');

        $('form').find(':submit').prop('disabled', false);

        $('form').on('submit', function(){
            $(this).find(':submit').prop('disabled', true);
            $('.fa-user').removeClass('fa-user').addClass('fa-spinner fa-pulse fa-fw');
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>