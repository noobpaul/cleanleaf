<div class="modal fade" tabindex="-1" role="dialog" id="login">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-body">
        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
          <?php echo e(csrf_field()); ?>


          <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
              <label for="username" class="col-md-12 control-label">E-Mail Address or Username</label>

              <div class="col-md-12">
                  <input id="username" type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>">

                  <?php if($errors->has('username')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('username')); ?></strong>
                      </span>
                  <?php endif; ?>
              </div>
          </div>

          <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
              <label for="password" class="col-md-12 control-label">Password</label>

              <div class="col-md-12">
                  <input id="password" type="password" class="form-control" name="password">

                  <?php if($errors->has('password')): ?>
                      <span class="help-block">
                          <strong><?php echo e($errors->first('password')); ?></strong>
                      </span>
                  <?php endif; ?>
              </div>
          </div>

          <div class="form-group">
              <div class="col-md-12">
                  <div class="checkbox">
                      <label>
                          <input type="checkbox" name="remember"> Remember Me
                      </label>
                  </div>
              </div>
          </div>

          <div class="form-group">
              <div class="col-md-12">
                  <button type="submit" class="btn btn-primary">
                      <i class="fa fa-btn fa-sign-in"></i> Login
                  </button>

                  <a class="btn btn-link" href="<?php echo e(url('/password/reset')); ?>">Forgot Your Password?</a>
              </div>
          </div>
      </form>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->