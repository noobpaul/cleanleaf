<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.welcome.hero', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('partials.welcome.about', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('partials.welcome.parallax', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- <?php echo $__env->make('partials.welcome.features', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->

    <?php echo $__env->make('partials.welcome.portfolio', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- <?php echo $__env->make('partials.welcome.team', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->

    <?php echo $__env->make('partials.welcome.contact', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
    <a class="scrolltop" href="#"><span class="fa fa-angle-up"></span></a>

    <?php echo $__env->make('partials.modals.login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>