<?php $__env->startSection('content'); ?>
	<div class="panel-group">
		<div class="panel panel-default">
			<div class="panel-body">
				<div class="row">
					<div class="col-md-3">
						<div class="panel panel-info">
							<div class="panel-heading ht100 text-center">
								<span class="fa fa-pencil fa-3x"></span>
								<h4>Job Order</h4>
							</div>
						</div>
					</div>
					<div class="col-md-3">
						<div class="panel panel-warning">
							<div class="panel-heading ht100 text-center">
								<span class="fa fa-book fa-3x"></span>
								<h4>Articles</h4>
							</div>
						</div>
					</div>
					<div class="col-md-3">
						<div class="panel panel-danger">
							<div class="panel-heading ht100 text-center">
								<span class="fa fa-address-book fa-3x"></span>
								<h4>A. Executives</h4>
							</div>
						</div>
					</div>
					<div class="col-md-3">
						<div class="panel panel-success">
							<div class="panel-heading ht100 text-center">
								<span class="fa fa-globe fa-3x"></span>
								<h4>Website</h4>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script>
		$('#dashboard').addClass('active');
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>