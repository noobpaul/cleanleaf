<?php $__env->startSection('content'); ?>
	<div class="panel-group">
		<div class="panel panel-default">
			<div class="panel-body">
				<label class="fc-blue" data-toggle="collapse" data-target="#changeAvatar"><span class="caret"></span> Avatar</label>
				<div class="row collapse in mgt15" id="changeAvatar">
					<div class="col-sm-4 col-sm-offset-4">
						<img src="<?php echo e(asset($user->image)); ?>" class="img-responsive img-circle img-thumbnail mgb15">
						<form action="<?php echo e(route('adminImage',$user->id)); ?>" method="post" enctype="multipart/form-data">
							<?php echo e(csrf_field()); ?>

							<?php echo e(method_field('patch')); ?>

							<input type="file" name="image" class="form-control input-sm" onchange="this.form.submit()">
						</form>
					</div>
				</div>
			</div>
		</div>
		<div class="panel panel-default">
			<div class="panel-body">
				<label class="fc-blue" data-toggle="collapse" data-target="#changeAccount"><span class="caret"></span> Account Settings</label>
				<form action="<?php echo e(route('adminSettingsUpdate',$user->id)); ?>" method="post" class="collapse mgt15" id="changeAccount">
					<?php echo e(csrf_field()); ?>

					<?php echo e(method_field('patch')); ?>

					<div class="row">
						<div class="col-sm-3">
							<label>Name</label>
						</div>
						<div class="col-sm-9">
	                        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
								<input type="text" name="name" class="form-control input-sm" placeholder="Full Name" value="<?php echo e($user->name); ?>">
								<?php if($errors->has('name')): ?>
	                                <span class="help-block">
	                                    <strong><?php echo e($errors->first('name')); ?></strong>
	                                </span>
	                            <?php endif; ?>
	                        </div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-3">
							<label>Username</label>
						</div>
						<div class="col-sm-9">
	                        <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
								<input type="text" name="username" class="form-control input-sm" placeholder="Username" value="<?php echo e($user->username); ?>">
								<?php if($errors->has('username')): ?>
	                                <span class="help-block">
	                                    <strong><?php echo e($errors->first('username')); ?></strong>
	                                </span>
	                            <?php endif; ?>
	                        </div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-3">
							<label>Email Address</label>
						</div>
						<div class="col-sm-9">
	                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
								<input type="email" name="email" class="form-control input-sm" placeholder="Email Address" value="<?php echo e($user->email); ?>">
								<?php if($errors->has('email')): ?>
	                                <span class="help-block">
	                                    <strong><?php echo e($errors->first('email')); ?></strong>
	                                </span>
	                            <?php endif; ?>
	                        </div>
						</div>
					</div>

					<div class="row">
						<div class="col-sm-12">
							<button type="submit" class="btn btn-primary pull-right"><span class="fa fa-check"></span> Save Changes</button>
						</div>
					</div>
				</form>
			</div>
		</div>

		<div class="panel panel-default">
			<div class="panel-body">
				<label class="fc-blue" data-toggle="collapse" data-target="#changePassword"><span class="caret"></span> Change Password</label>
				<form action="<?php echo e(route('adminPasswordUpdate',$user->id)); ?>" method="post" class="collapse mgt15" id="changePassword">
					<?php echo e(csrf_field()); ?>

					<?php echo e(method_field('patch')); ?>

					<div class="row">
						<div class="col-sm-3">
							<label>Old Password</label>
						</div>
						<div class="col-sm-9">
	                        <div class="form-group<?php echo e($errors->has('old_password') ? ' has-error' : ''); ?>">
								<input type="password" name="old_password" class="form-control input-sm" placeholder="Old Password">
								<?php if($errors->has('old_password')): ?>
	                                <span class="help-block">
	                                    <strong><?php echo e($errors->first('old_password')); ?></strong>
	                                </span>
	                            <?php endif; ?>
	                        </div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-3">
							<label>New Password</label>
						</div>
						<div class="col-sm-9">
	                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
								<input type="password" name="password" class="form-control input-sm" placeholder="New Password">
								<?php if($errors->has('password')): ?>
	                                <span class="help-block">
	                                    <strong><?php echo e($errors->first('password')); ?></strong>
	                                </span>
	                            <?php endif; ?>
	                        </div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-3">
							<label>Confirm Password</label>
						</div>
						<div class="col-sm-9">
	                        <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
								<input type="password" name="password_confirmation" class="form-control input-sm" placeholder="Confirm Password">
								<?php if($errors->has('password_confirmation')): ?>
	                                <span class="help-block">
	                                    <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
	                                </span>
	                            <?php endif; ?>
	                        </div>
						</div>
					</div>

					<div class="row">
						<div class="col-sm-12">
							<button type="submit" class="btn btn-primary pull-right"><span class="fa fa-check"></span> Change Password</button>
						</div>
					</div>
				</form>
			</div>
		</div>		
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script>
		$('#settings').addClass('active');
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>