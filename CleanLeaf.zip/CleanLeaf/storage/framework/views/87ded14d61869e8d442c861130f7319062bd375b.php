<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
		<?php echo e($user->name); ?>

	<?php if($job_order->status == true): ?>
		accepted
	<?php else: ?>
		rejected
	<?php endif; ?>
		your Job Order Request, <?php echo e($job_order->created_at); ?>

</body>
</html>