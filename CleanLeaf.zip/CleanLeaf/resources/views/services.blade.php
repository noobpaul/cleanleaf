@extends('layouts.app')

@section('content')

    @include('partials.nav')

    @include('partials.welcome.services-content')

    @include('partials.footer')
    
@stop