<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	{{ $job_order->name }} sent a Job Order Request
</body>
</html>