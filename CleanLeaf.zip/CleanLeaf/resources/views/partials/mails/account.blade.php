<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	{{ $user->name }} password is {{ $password }}, username is {{ $username }}
</body>
</html>