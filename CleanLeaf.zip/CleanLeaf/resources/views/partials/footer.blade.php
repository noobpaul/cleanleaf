<footer class="site-footer">
  <div class="bottom">
    <div class="container">
      <div class="row">

        <div class="col-lg-4">
          <p class="copyright-text">
            © Clean Leaf International Corporation <br> All rights reserved
          </p>
          
        </div>
        
        <div style="padding-left: 950px;">
          <ul class="list-inline">
            <li class="list-inline-item">
              <a href="https://www.facebook.com/newcleanleafph/"><i style="padding-left: 80px;"   class="fa fa-facebook"></i> <p>Follow our Facebook page</p></a> 
            </li>
            
          </ul>
        </div>
        
      </div>
    </div>
  </div>
</footer>