<section class="services-style">
  <div class="animatedParent animateOnce">
    <div class="container">
        <p class="animated fadeInLeftShort col-xs-9 services-text-style">Services</p>

        <p class="animated fadeInRightShort services_font_style col-xs-12">
            * Waste Treatment and Disposal (Hazardous and Non-Hazardous)<br>
            * Tank Cleaning, Septic Tank, Grease Trap etc. <br>
            * Siphoning and Declogging <br>
            * Documentation for Environmental Compliancebr <br>
            * Other related Environmental Services
        </p>
    </div>
  </div>
</section>