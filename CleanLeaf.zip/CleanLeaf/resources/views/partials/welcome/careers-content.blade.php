<section class="services-style">
  <div class="animatedParent animateOnce">
    <div class="container">
        <p class="animated fadeInLeftShort col-xs-9 services-text-style">Careers</p>

        <p class="animated fadeInRightShort services_font_style col-xs-12">
            Clean Leaf International Corporation is in need of: <br> 

            * Accounting Professionals <br>

            <br>
            If you are interested, you can send your resume at careers@cleanleaf.com.ph. <br>
            Thank you!
        </p>
    </div>
  </div>
</section>