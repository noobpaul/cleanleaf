<section class="team" id="team">
  <div class="container">
    <h2 class="text-center">
      Meet our Executives
    </h2>

    <div class="row">
      <div class="col-sm-3 col-xs-6">
        <div class="card card-block">
          <a href="#"><img alt="" class="team-img" src="img/sample.jpg">
          <div class="card-title-wrap">
            <span class="card-title">Sample</span> <span class="card-text">Sample</span>
          </div>

          <div class="team-over">
            <h4 class="hidden-md-down">
              Connect with me
            </h4>

            <nav class="social-nav">
              <a href="#"><i class="fa fa-twitter"></i></a> <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-linkedin"></i></a> <a href="#"><i class="fa fa-envelope"></i></a>
            </nav>

            <p>
              Lorem ipsum dolor sit amet, eu sed suas eruditi honestatis.
            </p>
          </div></a>
        </div>
      </div>

      <div class="col-sm-3 col-xs-6">
        <div class="card card-block">
          <a href="#"><img alt="" class="team-img" src="img/sample.jpg">
          <div class="card-title-wrap">
            <span class="card-title">Sample</span> <span class="card-text">Sample</span>
          </div>

          <div class="team-over">
            <h4 class="hidden-md-down">
              Connect with me
            </h4>

            <nav class="social-nav">
              <a href="#"><i class="fa fa-twitter"></i></a> <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-linkedin"></i></a> <a href="#"><i class="fa fa-envelope"></i></a>
            </nav>

            <p>
              Lorem ipsum dolor sit amet, eu sed suas eruditi honestatis.
            </p>
          </div></a>
        </div>
      </div>

      <div class="col-sm-3 col-xs-6">
        <div class="card card-block">
          <a href="#"><img alt="" class="team-img" src="img/sample.jpg">
          <div class="card-title-wrap">
            <span class="card-title">Sample</span> <span class="card-text">Sample</span>
          </div>

          <div class="team-over">
            <h4 class="hidden-md-down">
              Connect with me
            </h4>

            <nav class="social-nav">
              <a href="#"><i class="fa fa-twitter"></i></a> <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-linkedin"></i></a> <a href="#"><i class="fa fa-envelope"></i></a>
            </nav>

            <p>
              Lorem ipsum dolor sit amet, eu sed suas eruditi honestatis.
            </p>
          </div></a>
        </div>
      </div>

      <div class="col-sm-3 col-xs-6">
        <div class="card card-block">
          <a href="#"><img alt="" class="team-img" src="img/sample.jpg">
          <div class="card-title-wrap">
            <span class="card-title">Sample</span> <span class="card-text">Sample</span>
          </div>

          <div class="team-over">
            <h4 class="hidden-md-down">
              Connect with me
            </h4>

            <nav class="social-nav">
              <a href="#"><i class="fa fa-twitter"></i></a> <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-linkedin"></i></a> <a href="#"><i class="fa fa-envelope"></i></a>
            </nav>

            <p>
              Lorem ipsum dolor sit amet, eu sed suas eruditi honestatis.
            </p>
          </div></a>
        </div>
      </div>
    </div>
  </div>
</section>