@extends('layouts.app')

@section('content')

    @include('partials.nav')

    @include('partials.footer')
    
@stop