@extends('layouts.app')

@section('content')

    @include('partials.nav')

    @include('partials.welcome.careers-content')

    @include('partials.footer')
    
@stop