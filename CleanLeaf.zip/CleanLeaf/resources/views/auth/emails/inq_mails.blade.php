<h3>Quick Inquiry Form via Website</h3>

	<div>
		<p> Sent by : {{ $name_inq }} </p>
		<p> Contact info : {{ $contact_inq }} </p>
		<p> Company Name : {{ $company_inq }} </p>
	</div>

	<div>
		{{ $inq }}
	</div>
